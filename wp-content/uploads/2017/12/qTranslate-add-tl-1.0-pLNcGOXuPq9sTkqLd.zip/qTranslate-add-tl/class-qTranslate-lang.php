<?php
/**
 * Where all the qTranslate lang are rendered.
 *
 * @package qTranslate lang
 */


if ( ! defined( 'ABSPATH' ) ) { exit; // Exit if accessed directly.
}
// Initializes plugin class.
if ( ! class_exists( 'GambitqTranslateLang' ) ) {

	/**
	 * This is where all the plugin's functionality happens.
	 */
	class GambitqTranslateLang {

		/**
		 * Sets a unique identifier of each separator.
		 *
		 * @var int id - Separator count, that uniquely identifies each separator rendered.
		 */
		private static $id = 0;

		/**
		 * Hook into WordPress.
		 *
		 * @return	void
		 * @since	1.0
		 */
		function __construct() {
			// Makes the plugin function accessible as a shortcode.
			add_filter( 'the_content', array( $this, 'display_content' ) );
		}

		public function display_content( $content ) {
			$active_lang = qtranxf_getLanguage();
			if ( $active_lang == 'tl' ) {
				return preg_replace( "/(<a[^>]+href=['\"]https?\:\/\/roadsafety.ph)(\/en|\/tl)?/g", '$1/tl', $content );
			}
			return $content;
		}


	}
	new GambitqTranslateLang();
}
